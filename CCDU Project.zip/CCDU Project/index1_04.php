<?php
include('Session.php');
?>
<DOCTYPE html>
<html lang="en">
<head>
	<title>About</title>
	  <meta charset="UTF-8">
<style type="text/css">
a{color:black;}
</style>
</head>
<body>
<fieldset style=" background-color:green;">
   <p align="center"> <a href="index1.php">Home</a> | <a href="index1_01.php">Profile</a> | <a href="index1_02.php">Notifications</a> | <a href="index1_03.php">Messages</a></p>
</fieldset>
<br>
<h2 align="center"><u><i>About</i></u></h2>
<p>
Wits university proudly presents its Career Portal in Collaboration with WIDS. This dynamic portal
represents a central meeting point where students and alumni of Wits university and companies come
together.</p>

<p>As a current or former(recently graduated) student of Wits university this portal provides you with a
free account that will get you connected with right companies.</p>

<p>In this account you will be able to view and apply for jobs that suits your skills, as a graduate you will
get opportunities like internships, traineeships or entry level position. You will also be able able to view
upcoming events organised by various recruiters or by Wits Graduate Recruitment Programme in
partnership with CCDU(Counselling and Careers Development Unit). This events will help you find
your way in the labour market.<br>
The CCDU is a multi- disciplinary team who provide professional supportive services in a welcoming
and safe space to Wits students. The team endeavor to facilitate, contribute to and enhance the well-
being and self -empowerment of students, based on a an ethos of student-centeredness, inclusivity and
human rights</p>
<p>The CCDU team offer students:
<ul>
	<li>Individual and group counselling</li>
	<li>Career counselling and development</li>
	<li>Life coaching</li>
	<li>Psycho-educative workshops, training and advocacy programmes</li>
	<li>HIV education, advocacy and support</li>
	<li>Volunteer peer advocacy on social justice, mental health, and HIV</li>
	<li>Peer mentorship training</li>
	<li>Graduate recruitment</li>
	<li>The "Journey to Employability"</li>
	<li>Professional internships</li>
</ul>
<br>
Please follow this link<a style="color:blue;" href="https://goo.gl/forms/0v4fbIg8yGLOdne62"> https://goo.gl/forms/0v4fbIg8yGLOdne62</a> to sign up for University Student
Employment (USE). Opportunities range from part-time jobs, internships, bursaries, to vacation work.</p>

<p>Career Services at Wits wishes to collect and analyse students use, reach and satisfaction for the
following.<br>
Number of students reached through our chargeable, non-chargeable services and events.
Number of career of career services events attended per student, within a particular academic year.
Number of smses/emails received by a student from career services inviting them to an activity or
informing them of an opportunity.
Number of students reached via career services activities category in a specific academic calender.
Analyse the utilisation of online resources.
Survey students to identify frequently used methods for career information.
This information will be used to inform career services strategies and responses.</p>
</body>
<html>
