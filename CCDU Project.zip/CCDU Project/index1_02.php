<?php
include('Session.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Notifications</title>
      <link rel="stylesheet" href="navbar.css">
</head>
<body>
<nav>
  <ul>
    <li><a href="index1.php">Home</a></li>
    <li><a href="index1_01.php">Profile</a></li>
    <li><a href="index1_03.php">Messages</a></li>
    <li><a href="index1_04.php">About</a></li>
  </ul>
</nav>
<br>
<?php require_once"notification.php"; ?>
</body>
</html>
