<?php
session_start()

?>

<!DOCTYPE html>
<html>
<head>
   <meta charset="UTF-8">
   <title>Successful Upload </title>
</head>

<body>
<h1>Congratulations your event has been successfuly posted.<h1>
<br>
<p><a href="index2.php">Return home</a></p>
</body>
</html>
