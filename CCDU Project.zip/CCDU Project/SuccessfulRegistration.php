<?php
include_once"config.php"
?>
<!DOCTYPE html>
<html lang="eng">
<head>
<title>Successful Registration</title>
</head>

<body>
<h1>Registration Successful</h1>
<p>Thank you for creating an account,<br>Please Go to<a href="StudentHomePage.php"> Login here</a>.</p>


</body>

</html>
