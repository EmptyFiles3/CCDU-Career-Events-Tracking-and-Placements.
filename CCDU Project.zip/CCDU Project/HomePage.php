
<?php
require_once "config.php";
?>


<DOCTYPE html>
<html lang="en">

<head>
 <meta charset="UTF-8">
<title>Home-Page</title>
	<!-- CSS CODE STARTS HERE -->
<style type="text/css">
p.nine{
	color:rgb(255,255,255);}
p.ten{
	color:rgb(255,255,255);}
p.eleven{
	color:rgb(255,255,255);}
p.twelve{
	color:rgb(255,255,255);}
p.thirteen{
	color:rgb(255,255,255);}
p.fourteen,h3{
	color: rgb(255,255,255); }
fieldset{
	font-size:75%; text-align:center;}

</style>	<!-- CSS CODE ENDS HERE -->
</head>
	<!-- BODY STARTS HERE -->
<body> 
<p>
<div id="header">
	<?php echo'<img src="ImagesCCDU/image009.jpg"/>'?>
	<img src="ImagesCCDU/image003.png" height="295px" /><br>
	<?php echo'<img src="ImagesCCDU/image001.jpg" width="100%"/>' ?>
</div>	</p>

<h1>Welcome to Wits Career Portal HomePage</h1>
<p> WITS University proudly presents its Career Portal in collaboration with WIDS. This dynamic portal represents a central meeting point where students and alumni of WITS University and companies come together.</p>

<img src="ImagesCCDU/WA0001.jpg"  height="550px" width="100%"/>
<marquee behaviour="stop"></marquee>
			<!-- Link to next Page -->
<p>Are you a Student or an Organization? then click below to login or to create an account:</p>
<p><a href="StudentHomePage.php"><b>Students</b></a><br>
<a href="EmployerHomePage.php"><b>Organization</b></a></p>

<h4>Career tips, events, internships, side-jobs and entry-level jobs for student and alumni.</h4>
<ul>
	<li>Are you a student or former student of WITS and are looking for an internship, traineeship,part-time job or entry-level position?</li>
	<li>Would you like to attend events that can help you find your way in the labour market?</li>
	<li>Or do you just want to get inspired by career-related articles, tips and tricks?</li>
</ul>
<p>Then our Career Portal can open up a world of possibilities. We can help you get connected with the right companies!<br>Already Graduated?<br>You can sign up for the Career Portal or extend your student account until one year after graduation.</p>
<p>If you can't login anymore or would like to sign up for the Career Portal, please send an e-mail to studentcareerservices@wits.ac.za</p>
<p>Free App!<br>Do you want to get the latest content in the Career Portal on the go? There's a free app for Android and iOS.</p>



<p align="right">
</p>


	<!-- Bottom of the page start here -->
<fieldset style="background-color:navy;" >
<p><h3>Contact Us</h3></p>
<p class="nine">General enquiries<br>Tel: +27(0)11 717 1000<br>Admission enquiries<br>Tel: +27(0)11 717 1888</p> 
<p><h3>Find Us</h3></p>
<p class="ten">1 Jan Smuts Avenue,<br>Braamfontein 2000,<br>Johannesburg,<br>South Africa</p>
<p><h3>Quicklinks</h3> </p>
<p class="eleven">Vacancies<br>Term dates<br>Tenders<br>Maps</p>
<p><h3>Connect with us</h3></p>
<p><img src="ImagesCCDU/image006.png" />
	<img src="ImagesCCDU/image007.jpg" />
	<img src="ImagesCCDU/image008.png" />
</p>
<p class="thirteen">Copyright &copy 2000-2020-University of the Witwatersrand,Johannesburg.</p>

</fieldset> <!-- Bottom of the page ends here -->

</body>		<!-- BODY ENDS HERE -->

</html>
